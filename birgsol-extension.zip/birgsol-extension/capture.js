// BIRGSOL הזרוע — לוכד קונסולה + רשת (רץ ב-MAIN world מרגע טעינת הדף).
// שומר את ההודעות האחרונות ומשקף אותן לצומת DOM נסתר (#__birgsol_cap__) כדי שה-service worker
// (שרץ ב-isolated world) יוכל לקרוא אותן ולתת לסוכן "לראות" שגיאות ובקשות רשת — כמו כלי מפתחים.
(function () {
  if (window.__birgsolCapInit) return; window.__birgsolCapInit = true;
  var logs = [], net = [], _t = null;
  function mirror() {
    if (_t) return;
    _t = setTimeout(function () {
      _t = null;
      try {
        var n = document.getElementById('__birgsol_cap__');
        if (!n) { n = document.createElement('div'); n.id = '__birgsol_cap__'; n.style.display = 'none'; (document.documentElement || document).appendChild(n); }
        n.textContent = JSON.stringify({ logs: logs.slice(-40), net: net.slice(-40) });
      } catch (e) {}
    }, 400);
  }
  function push(arr, item) { arr.push(item); if (arr.length > 60) arr.shift(); mirror(); }
  // ---- לכידת console ----
  ['log', 'info', 'warn', 'error', 'debug'].forEach(function (lv) {
    var orig = console[lv];
    console[lv] = function () {
      try {
        var s = Array.prototype.map.call(arguments, function (a) {
          try { return typeof a === 'string' ? a : (a && a.message) ? ('Error: ' + a.message) : JSON.stringify(a); }
          catch (e) { return String(a); }
        }).join(' ').slice(0, 300);
        push(logs, { lv: lv, m: s, t: Date.now() });
      } catch (e) {}
      return orig && orig.apply(console, arguments);
    };
  });
  // ---- שגיאות לא-מטופלות ----
  window.addEventListener('error', function (e) {
    try { push(logs, { lv: 'error', m: (e.message || 'error') + (e.filename ? (' @' + String(e.filename).split('/').pop() + ':' + e.lineno) : ''), t: Date.now() }); } catch (_) {}
  }, true);
  window.addEventListener('unhandledrejection', function (e) {
    try { push(logs, { lv: 'error', m: 'unhandled: ' + ((e.reason && e.reason.message) || e.reason || '').toString().slice(0, 200), t: Date.now() }); } catch (_) {}
  });
  // ---- לכידת fetch ----
  var of = window.fetch;
  if (of) window.fetch = function () {
    var url = '', m = 'GET';
    try { url = (arguments[0] && arguments[0].url) || String(arguments[0] || ''); } catch (e) {}
    try { m = (arguments[1] && arguments[1].method) || (arguments[0] && arguments[0].method) || 'GET'; } catch (e) {}
    var t0 = Date.now();
    return of.apply(this, arguments).then(function (r) {
      try { push(net, { u: url.slice(0, 160), s: r.status, ok: r.ok, ms: Date.now() - t0, m: m }); } catch (e) {}
      return r;
    }).catch(function (err) {
      try { push(net, { u: url.slice(0, 160), s: 0, ok: false, err: String(err && err.message || err).slice(0, 80), m: m }); } catch (e) {}
      throw err;
    });
  };
  // ---- לכידת XHR ----
  try {
    var OX = window.XMLHttpRequest;
    if (OX) {
      var op = OX.prototype.open, sn = OX.prototype.send;
      OX.prototype.open = function (m, u) { this.__bm = m; this.__bu = u; return op.apply(this, arguments); };
      OX.prototype.send = function () {
        var x = this, t0 = Date.now();
        try { x.addEventListener('loadend', function () { try { push(net, { u: String(x.__bu || '').slice(0, 160), s: x.status, ok: x.status >= 200 && x.status < 400, ms: Date.now() - t0, m: x.__bm || 'GET' }); } catch (e) {} }); } catch (e) {}
        return sn.apply(this, arguments);
      };
    }
  } catch (e) {}
})();
