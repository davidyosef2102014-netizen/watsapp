// BIRGSOL AI — הזרוע (service worker) v2.0.0 — סוכן דפדפן: קורא, מצלם, ו*פועל* (לוחץ/מקליד/גולל).
// נשלטת מתוך אפליקציית BIRGSOL (github.io) דרך externally_connectable.
// פקודות: birgsol-ping (בדיקה) · birgsol-look (האר+קרא+צלם) · birgsol-act (בצע פעולה) · birgsol-stop (כבה).

const APP_MATCH = 'davidyosef2102014-netizen.github.io/watsapp';

// ---- זוהר "BIRGSOL עובד" ----
function _glowInject() {
  if (document.getElementById('__birgsol_glow__')) return;
  const st = document.createElement('style'); st.id = '__birgsol_glow_st__';
  st.textContent = '@keyframes __bpulse{0%,100%{box-shadow:inset 0 0 0 3px rgba(66,133,244,.9),inset 0 0 24px 7px rgba(64,196,255,.5)}50%{box-shadow:inset 0 0 0 4px rgba(64,196,255,1),inset 0 0 40px 12px rgba(66,133,244,.75)}}';
  const g = document.createElement('div'); g.id = '__birgsol_glow__';
  g.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2147483646;animation:__bpulse 2.2s ease-in-out infinite;';
  const btn = document.createElement('button'); btn.id = '__birgsol_stop__';
  btn.textContent = '■ STOP BIRGSOL';
  btn.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:2147483647;pointer-events:auto;background:linear-gradient(135deg,#4285F4,#40C4FF);color:#fff;border:none;border-radius:999px;padding:9px 20px;font:700 14px system-ui,sans-serif;cursor:pointer;box-shadow:0 6px 26px rgba(66,133,244,.55);letter-spacing:.3px;';
  btn.addEventListener('click', () => { window.__birgsolStop = true;
    ['__birgsol_glow__', '__birgsol_glow_st__', '__birgsol_stop__'].forEach(id => { const el = document.getElementById(id); if (el) el.remove(); });
  });
  document.documentElement.appendChild(st);
  document.documentElement.appendChild(g);
  document.documentElement.appendChild(btn);
}
function _glowRemove() {
  ['__birgsol_glow__', '__birgsol_glow_st__', '__birgsol_stop__'].forEach(id => { const el = document.getElementById(id); if (el) el.remove(); });
}

// ---- קריאת הדף: מתייג כל אלמנט אינטראקטיבי ב-data-bref כדי שאפשר יהיה לפעול עליו לפי מספר ----
function _readPage() {
  const clip = s => (s || '').replace(/\s+/g, ' ').trim().slice(0, 90);
  const fields = [];
  try {
    const sel = 'input, textarea, select, button, a[href], [role="button"], [role="link"], [role="checkbox"], [role="tab"], [contenteditable="true"]';
    let i = 0;
    document.querySelectorAll(sel).forEach(el => {
      if (el.type === 'hidden') return;
      const r = el.getBoundingClientRect();
      if (r.width < 4 || r.height < 4) return;
      if (r.bottom < 0 || r.top > (window.innerHeight || 9999) + 1200) return; // רחוק מדי מחוץ למסך
      const stl = window.getComputedStyle(el);
      if (stl.display === 'none' || stl.visibility === 'hidden' || stl.opacity === '0') return;
      const tag = el.tagName.toLowerCase();
      const type = (el.getAttribute('type') || '').toLowerCase();
      let label = '';
      if (el.id) { try { const lb = document.querySelector('label[for="' + CSS.escape(el.id) + '"]'); if (lb) label = lb.innerText; } catch (e) {} }
      label = label || el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.getAttribute('name') ||
              ((tag === 'a' || tag === 'button' || el.getAttribute('role')) ? el.innerText : '') || el.getAttribute('title') || el.value || '';
      el.setAttribute('data-bref', String(i));
      const f = {
        ref: i,
        kind: tag === 'input' ? (type || 'text') : tag,
        label: clip(label),
        x: Math.round(r.left + r.width / 2),
        y: Math.round(r.top + r.height / 2)
      };
      if (tag === 'input' || tag === 'textarea') { f.value = clip(el.value || ''); }
      if (type === 'checkbox' || type === 'radio') { f.checked = !!el.checked; }
      fields.push(f);
      i++;
    });
  } catch (e) {}
  return {
    title: document.title,
    url: location.href,
    text: (document.body ? document.body.innerText : '').replace(/\n{3,}/g, '\n\n').slice(0, 9000),
    fields: fields.slice(0, 120),
    stopped: !!window.__birgsolStop
  };
}

// ---- ביצוע פעולה בתוך הדף ----
async function _actInject(action) {
  const out = { ok: false };
  // 🖱️ סמן-עכבר מונפש — כדי שרואים את BIRGSOL "זז" בדף לפני כל פעולה
  const _sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const _cursor = () => {
    let c = document.getElementById('__birgsol_cursor__');
    if (!c) {
      c = document.createElement('div'); c.id = '__birgsol_cursor__';
      c.style.cssText = 'position:fixed;z-index:2147483647;width:24px;height:24px;left:0;top:0;pointer-events:none;transition:left .5s cubic-bezier(.45,0,.25,1),top .5s cubic-bezier(.45,0,.25,1);filter:drop-shadow(0 2px 4px rgba(0,0,0,.4));will-change:left,top;';
      c.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="#4285F4" stroke="#ffffff" stroke-width="1.6" stroke-linejoin="round"><path d="M5 3l15 8-6.5 1.8L11 20z"/></svg>';
      document.documentElement.appendChild(c);
    }
    return c;
  };
  const _moveCursorTo = async (x, y) => { const c = _cursor(); c.style.left = (x - 3) + 'px'; c.style.top = (y - 2) + 'px'; await _sleep(560); };
  const _pulse = (x, y) => { try { const p = document.createElement('div'); p.style.cssText = 'position:fixed;z-index:2147483646;left:' + (x - 14) + 'px;top:' + (y - 14) + 'px;width:28px;height:28px;border:2px solid #4285F4;border-radius:50%;pointer-events:none;opacity:.9;transition:transform .4s,opacity .4s'; document.documentElement.appendChild(p); requestAnimationFrame(() => { p.style.transform = 'scale(2)'; p.style.opacity = '0'; }); setTimeout(() => p.remove(), 450); } catch (e) {} };
  try {
    if (window.__birgsolStop) return { ok: false, error: 'stopped-by-user' };
    const byRef = (ref) => document.querySelector('[data-bref="' + String(ref) + '"]');
    const op = action && action.op;
    if (op === 'click') {
      const el = byRef(action.ref); if (!el) return { ok: false, error: 'element not found: ' + action.ref };
      el.scrollIntoView({ block: 'center', behavior: 'smooth' });
      await _sleep(250);
      const r = el.getBoundingClientRect(); const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      await _moveCursorTo(cx, cy); // העכבר נע לאלמנט — נראה לעין
      _pulse(cx, cy);
      ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(t => {
        try { el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy })); } catch (e) {}
      });
      try { el.click(); } catch (e) {}
      out.ok = true;
    } else if (op === 'type') {
      const el = byRef(action.ref); if (!el) return { ok: false, error: 'element not found: ' + action.ref };
      el.scrollIntoView({ block: 'center', behavior: 'smooth' });
      await _sleep(250);
      const _r = el.getBoundingClientRect(); await _moveCursorTo(_r.left + _r.width / 2, _r.top + _r.height / 2); // העכבר נע לשדה
      el.focus();
      const val = action.text != null ? String(action.text) : '';
      if (el.isContentEditable) { el.textContent = val; }
      else {
        const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value') && Object.getOwnPropertyDescriptor(proto, 'value').set;
        if (setter) setter.call(el, val); else el.value = val;
      }
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      out.ok = true;
    } else if (op === 'key') {
      const el = document.activeElement || document.body;
      const key = action.key || 'Enter';
      ['keydown', 'keypress', 'keyup'].forEach(t => {
        try { el.dispatchEvent(new KeyboardEvent(t, { key, code: key, bubbles: true })); } catch (e) {}
      });
      // Enter על שדה בטופס → נסה submit
      if (key === 'Enter' && el && el.form) { try { el.form.requestSubmit ? el.form.requestSubmit() : el.form.submit(); } catch (e) {} }
      out.ok = true;
    } else if (op === 'scroll') {
      const amt = action.dir === 'up' ? -Math.round(window.innerHeight * 0.8) : Math.round(window.innerHeight * 0.8);
      window.scrollBy({ top: amt, behavior: 'instant' }); out.ok = true;
    } else if (op === 'select') {
      const el = byRef(action.ref); if (!el) return { ok: false, error: 'element not found: ' + action.ref };
      const want = String(action.text || '').toLowerCase();
      let done = false;
      for (const o of el.options || []) { if ((o.text || '').toLowerCase().includes(want) || (o.value || '').toLowerCase() === want) { el.value = o.value; done = true; break; } }
      el.dispatchEvent(new Event('change', { bubbles: true })); out.ok = done;
    } else if (op === 'exec') {
      // הרצת JavaScript בדף (מתקדם) — כמו קונסולת המפתחים. מחזיר את הערך שהוחזר.
      try { const R = (0, eval)(String(action.code || '')); out.ok = true; out.result = (R === undefined ? '(no return value)' : (typeof R === 'object' ? JSON.stringify(R) : String(R))).slice(0, 3000); }
      catch (e) { return { ok: false, error: 'exec error: ' + (e && e.message || e) }; }
    } else { return { ok: false, error: 'unknown op: ' + op }; }
  } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
  return out;
}

async function _targetTab() {
  const notApp = t => t && t.url && /^https?:\/\//.test(t.url) && t.url.indexOf(APP_MATCH) === -1;
  // עדיפות 1: הטאב הפעיל שהמשתמש מסתכל עליו (הכי צפוי) — כל עוד אינו BIRGSOL עצמו
  try { const [act] = await chrome.tabs.query({ active: true, lastFocusedWindow: true }); if (notApp(act)) return act; } catch (e) {}
  try { const [act2] = await chrome.tabs.query({ active: true, currentWindow: true }); if (notApp(act2)) return act2; } catch (e) {}
  // עדיפות 2: הטאב שנצפה לאחרונה שאינו BIRGSOL
  const tabs = await chrome.tabs.query({});
  const cand = tabs.filter(notApp);
  cand.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  if (cand.length) return cand[0];
  // אין אף טאב מתאים → פותחים אחד לבד (כדי שהסוכן תמיד יוכל לפעול, בלי "לא מצאתי דף")
  try { const nt = await chrome.tabs.create({ url: 'https://www.google.com', active: true }); await new Promise(r => setTimeout(r, 1400)); return nt; } catch (e) { return null; }
}

async function _look(withShot) {
  const tab = await _targetTab();
  if (!tab || tab.id == null) return { ok: false, error: 'no-page' };
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: _glowInject });
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: _readPage });
    const page = (r && r.result) ? r.result : { title: tab.title, url: tab.url, text: '' };
    let screenshot = null;
    if (withShot !== false) {
      try {
        await chrome.tabs.update(tab.id, { active: true });
        await new Promise(res => setTimeout(res, 220));
        screenshot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 60 });
      } catch (e) {}
    }
    return { ok: true, title: page.title, url: page.url, text: page.text, fields: page.fields || [], stopped: page.stopped, screenshot };
  } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
}

// בצע פעולה → המתן → החזר את מצב הדף החדש (כדי שהסוכן "יראה" מה קרה)
async function _act(action) {
  const tab = await _targetTab();
  if (!tab || tab.id == null) return { ok: false, error: 'no-page' };
  try {
    let execResult = null;
    if (action && action.op === 'navigate' && action.url) {
      try { await chrome.tabs.update(tab.id, { url: action.url }); } catch (e) { return { ok: false, error: 'nav failed' }; }
      await new Promise(res => setTimeout(res, 1500));
    } else if (action && action.op === 'wait') {
      await new Promise(res => setTimeout(res, Math.min(6000, action.ms || 1200)));
    } else {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: _actInject, args: [action] });
      const res = (r && r.result) ? r.result : { ok: false, error: 'no-result' };
      if (!res.ok) return { ok: false, error: res.error || 'act failed', ...(await _look(false)) };
      if (res.result != null) execResult = res.result; // תוצאת exec
      await new Promise(res2 => setTimeout(res2, 900)); // תן לדף להגיב
    }
    const state = await _look(true);
    return { ok: true, acted: true, execResult, ...state };
  } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
}

async function _stopAll() {
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) {
    if (t.url && /^https?:\/\//.test(t.url)) {
      try { await chrome.scripting.executeScript({ target: { tabId: t.id }, func: _glowRemove }); } catch (e) {}
    }
  }
  return { ok: true };
}

// ---- הגשר: הודעות מאפליקציית BIRGSOL ----
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (!sender || !sender.url || sender.url.indexOf(APP_MATCH) === -1) { sendResponse({ ok: false, error: 'forbidden' }); return; }
  (async () => {
    try {
      if (msg && msg.type === 'birgsol-ping') sendResponse({ ok: true, installed: true, version: '2.1.2', agent: true });
      else if (msg && msg.type === 'birgsol-look') sendResponse(await _look(true));
      else if (msg && msg.type === 'birgsol-act')  sendResponse(await _act(msg.action || {}));
      else if (msg && msg.type === 'birgsol-stop') sendResponse(await _stopAll());
      else sendResponse({ ok: false, error: 'unknown-command' });
    } catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
  })();
  return true;
});

chrome.action.onClicked.addListener(async (tab) => {
  if (tab && tab.id != null && /^https?:\/\//.test(tab.url || '')) {
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: _glowInject }); } catch (e) {}
  }
});
