// BIRGSOL AI — הזרוע (service worker).
// נשלטת מתוך אפליקציית BIRGSOL (github.io) דרך externally_connectable.
// פקודות: 'birgsol-look' (האר + קרא + צלם + החזר), 'birgsol-stop' (כבה זוהר), 'birgsol-ping' (בדיקת חיבור).

const APP_MATCH = 'davidyosef2102014-netizen.github.io/watsapp';

// ---- פונקציות שמוזרקות לתוך הדף ----
function _glowInject() {
  if (document.getElementById('__birgsol_glow__')) return;
  const st = document.createElement('style'); st.id = '__birgsol_glow_st__';
  st.textContent = '@keyframes __bpulse{0%,100%{box-shadow:inset 0 0 0 3px rgba(66,133,244,.9),inset 0 0 24px 7px rgba(64,196,255,.5)}50%{box-shadow:inset 0 0 0 4px rgba(64,196,255,1),inset 0 0 40px 12px rgba(66,133,244,.75)}}';
  const g = document.createElement('div'); g.id = '__birgsol_glow__';
  g.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2147483646;animation:__bpulse 2.2s ease-in-out infinite;';
  const btn = document.createElement('button'); btn.id = '__birgsol_stop__';
  btn.textContent = '■ STOP BIRGSOL';
  btn.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:2147483647;pointer-events:auto;background:linear-gradient(135deg,#4285F4,#40C4FF);color:#fff;border:none;border-radius:999px;padding:9px 20px;font:700 14px system-ui,sans-serif;cursor:pointer;box-shadow:0 6px 26px rgba(66,133,244,.55);letter-spacing:.3px;';
  btn.addEventListener('click', () => {
    ['__birgsol_glow__', '__birgsol_glow_st__', '__birgsol_stop__'].forEach(id => { const el = document.getElementById(id); if (el) el.remove(); });
  });
  document.documentElement.appendChild(st);
  document.documentElement.appendChild(g);
  document.documentElement.appendChild(btn);
}
function _glowRemove() {
  ['__birgsol_glow__', '__birgsol_glow_st__', '__birgsol_stop__'].forEach(id => { const el = document.getElementById(id); if (el) el.remove(); });
}
function _readPage() {
  return { title: document.title, url: location.href, text: (document.body ? document.body.innerText : '').slice(0, 14000) };
}

// הטאב שהמשתמש הביט בו לאחרונה — לא אפליקציית BIRGSOL ולא עמוד מערכת
async function _targetTab() {
  const tabs = await chrome.tabs.query({});
  const cand = tabs.filter(t => t.url && /^https?:\/\//.test(t.url) && t.url.indexOf(APP_MATCH) === -1);
  cand.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  return cand[0] || null;
}

async function _look() {
  const tab = await _targetTab();
  if (!tab || tab.id == null) return { ok: false, error: 'no-page' };
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: _glowInject });
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: _readPage });
    const page = (r && r.result) ? r.result : { title: tab.title, url: tab.url, text: '' };
    let screenshot = null;
    try {
      await chrome.tabs.update(tab.id, { active: true });
      await new Promise(res => setTimeout(res, 250)); // תן לטאב לצוף לפני צילום
      screenshot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 65 });
    } catch (e) { /* צילום נכשל — נמשיך עם טקסט בלבד */ }
    return { ok: true, title: page.title, url: page.url, text: page.text, screenshot };
  } catch (e) {
    return { ok: false, error: String(e && e.message || e) };
  }
}

async function _stopAll() {
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) {
    if (t.url && /^https?:\/\//.test(t.url)) {
      try { await chrome.scripting.executeScript({ target: { tabId: t.id }, func: _glowRemove }); } catch (e) {}
    }
  }
  return { ok: true };
}

// ---- הגשר: הודעות מאפליקציית BIRGSOL ----
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  // externally_connectable כבר מגביל למקור של האפליקציה; בדיקה כפולה ליתר ביטחון
  if (!sender || !sender.url || sender.url.indexOf(APP_MATCH) === -1) { sendResponse({ ok: false, error: 'forbidden' }); return; }
  (async () => {
    try {
      if (msg && msg.type === 'birgsol-ping') sendResponse({ ok: true, installed: true, version: '1.1.0' });
      else if (msg && msg.type === 'birgsol-look') sendResponse(await _look());
      else if (msg && msg.type === 'birgsol-stop') sendResponse(await _stopAll());
      else sendResponse({ ok: false, error: 'unknown-command' });
    } catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
  })();
  return true; // תשובה אסינכרונית
});

// לחיצה על האייקון = מאירים את הדף הנוכחי (קצוות זוהרים + STOP BIRGSOL) ומחכים.
// המודל ניגש לתוכן מהאפליקציה ("תסתכל בדפדפן"). לא פותחים שום דבר.
chrome.action.onClicked.addListener(async (tab) => {
  if (tab && tab.id != null && /^https?:\/\//.test(tab.url || '')) {
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: _glowInject }); } catch (e) {}
  }
});
